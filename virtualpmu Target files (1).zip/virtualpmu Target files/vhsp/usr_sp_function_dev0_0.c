// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------

#include "math.h"
#include <stdint.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"

// H files from Advanced C Function components

// Header files from additional sources (Advanced C Function)
// ----------------------------------------------------------------------------------------
// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines





























































































































































































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables


//@cmp.var.start
// variables
double _bus2_on__out;
double _bus2_q_ref__out;
double _bus4_on__out;
double _bus4_q_ref__out;
double _bus5_on__out;
double _bus5_q_ref__out;
static X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
double _communication_bus2_va1_va1__out;
double _communication_bus2_va4_va1__out;
double _communication_bus2_va5_va1__out;
static X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
double _communication_bus4_va1_va1__out;
double _communication_bus4_va4_va1__out;
double _communication_bus4_va5_va1__out;
static X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_iq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
static X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_vq__out[4] = { 0.0, 0.0, 0.0, 0.0 };
double _communication_bus5_va1_va1__out;
double _communication_bus5_va4_va1__out;
double _communication_bus5_va5_va1__out;
double _bus2_bus_join1__out[2];
double _bus4_bus_join1__out[2];
double _bus5_bus_join1__out[2];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[3];
double _communication_bus2_neutro__out;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[3];
double _communication_bus4_sum1__out;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[4];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[0];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[0];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[1];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[1];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[2];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[2];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[3];
char *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[3];
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[4];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[0];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[0];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[1];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[1];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[2];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[2];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[3];
char *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[3];
double _communication_bus5_sum1__out;
double _bus_join1__out[6];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out3;
double _communication_bus2_bus_join1__out[4];
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out3;
double _communication_bus4_bus_join1__out[4];
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out3;
double _communication_bus5_bus_join1__out[4];
double _pv_out_bus_split1__out[2];
double _pv_out_bus_split1__out1[2];
double _pv_out_bus_split1__out2[2];
double _communication_bus2_line_2_1_sv_publisher2_i_scale__out[4];
double _communication_bus2_line_2_1_sv_publisher2_v_scale__out[4];
double _communication_bus2_line_2_3_sv_publisher2_i_scale__out[4];
double _communication_bus2_line_2_3_sv_publisher2_v_scale__out[4];
double _communication_bus2_line_2_4_sv_publisher2_i_scale__out[4];
double _communication_bus2_line_2_4_sv_publisher2_v_scale__out[4];
double _communication_bus2_line_2_5_sv_publisher2_i_scale__out[4];
double _communication_bus2_line_2_5_sv_publisher2_v_scale__out[4];
double _communication_bus2_line_2_6_sv_publisher2_i_scale__out[4];
double _communication_bus2_line_2_6_sv_publisher2_v_scale__out[4];
double _communication_bus4_line_4_2_sv_publisher2_i_scale__out[4];
double _communication_bus4_line_4_2_sv_publisher2_v_scale__out[4];
double _communication_bus4_line_4_5_sv_publisher2_i_scale__out[4];
double _communication_bus4_line_4_5_sv_publisher2_v_scale__out[4];
double _communication_bus5_line_5_1_sv_publisher2_i_scale__out[4];
double _communication_bus5_line_5_1_sv_publisher2_v_scale__out[4];
double _communication_bus5_line_5_2_sv_publisher2_i_scale__out[4];
double _communication_bus5_line_5_2_sv_publisher2_v_scale__out[4];
double _communication_bus5_line_5_3_sv_publisher2_i_scale__out[4];
double _communication_bus5_line_5_3_sv_publisher2_v_scale__out[4];
double _communication_bus5_line_5_4_sv_publisher2_i_scale__out[4];
double _communication_bus5_line_5_4_sv_publisher2_v_scale__out[4];
double _communication_bus5_line_5_6_sv_publisher2_i_scale__out[4];
double _communication_bus5_line_5_6_sv_publisher2_v_scale__out[4];
X_Int32 _communication_bus2_line_2_1_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus2_line_2_1_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus2_line_2_3_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus2_line_2_3_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus2_line_2_4_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus2_line_2_4_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus2_line_2_5_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus2_line_2_5_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus2_line_2_6_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus2_line_2_6_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus4_line_4_2_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus4_line_4_2_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus4_line_4_5_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus4_line_4_5_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus5_line_5_1_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus5_line_5_1_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus5_line_5_2_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus5_line_5_2_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus5_line_5_3_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus5_line_5_3_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus5_line_5_4_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus5_line_5_4_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus5_line_5_6_sv_publisher2_i_convert__out[4];
X_Int32 _communication_bus5_line_5_6_sv_publisher2_v_convert__out[4];
X_Int32 _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[4];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[0];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[0];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[1];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[1];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[2];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[2];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[3];
char *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[3];
X_Int32 _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[4];
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[4];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[0];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr0 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[0];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[1];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr1 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[1];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[2];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr2 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[2];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[3];
char *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr3 = (char *) &_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[3];
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out3;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out1;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out2;
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out3;
X_UnInt32 _communication_bus2_line_2_1_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus2_line_2_3_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus2_line_2_4_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus2_line_2_5_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus2_line_2_6_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus4_line_4_2_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus4_line_4_5_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus5_line_5_1_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus5_line_5_2_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus5_line_5_3_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus5_line_5_4_sv_publisher2_bus_join__out[16];
X_UnInt32 _communication_bus5_line_5_6_sv_publisher2_bus_join__out[16];
//@cmp.var.end

//@cmp.svar.start
// state variables
//@cmp.svar.end





// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    HIL_OutAO(0x2009, 0.0f);
    HIL_OutAO(0x200a, 0.0f);
    HIL_OutAO(0x200b, 0.0f);
    HIL_OutAO(0x200c, 0.0f);
    HIL_OutAO(0x200d, 0.0f);
    HIL_OutAO(0x200e, 0.0f);
    //@cmp.init.block.end
}

void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}

void init_fmu_objects_cpu0_dev0(void) {
    return;
}


void terminate_fmu_objects_cpu0_dev0(void) {
    return;
}
// generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) ((value > limit) ? value : limit)
#endif
#ifndef MIN
#define MIN(value, limit) ((value < limit) ? value : limit)
#endif

// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Bus2.On
    _bus2_on__out = XIo_InFloat(0x55000148);
    // Generated from the component: Bus2.Q_ref
    _bus2_q_ref__out = XIo_InFloat(0x5500014c);
    // Generated from the component: Bus4.On
    _bus4_on__out = XIo_InFloat(0x55000150);
    // Generated from the component: Bus4.Q_ref
    _bus4_q_ref__out = XIo_InFloat(0x55000154);
    // Generated from the component: Bus5.On
    _bus5_on__out = XIo_InFloat(0x55000158);
    // Generated from the component: Bus5.Q_ref
    _bus5_q_ref__out = XIo_InFloat(0x5500015c);
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.IQ
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.VQ
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.IQ
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.VQ
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.IQ
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.VQ
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.IQ
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.VQ
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.IQ
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.VQ
    // Generated from the component: Communication.Bus2.Va1.Va1
    _communication_bus2_va1_va1__out = (HIL_InFloat(0xc80000 + 0x0));
    // Generated from the component: Communication.Bus2.Va4.Va1
    _communication_bus2_va4_va1__out = (HIL_InFloat(0xc80000 + 0x1));
    // Generated from the component: Communication.Bus2.Va5.Va1
    _communication_bus2_va5_va1__out = (HIL_InFloat(0xc80000 + 0x2));
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.IQ
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.VQ
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.IQ
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.VQ
    // Generated from the component: Communication.Bus4.Va1.Va1
    _communication_bus4_va1_va1__out = (HIL_InFloat(0xc80000 + 0x6));
    // Generated from the component: Communication.Bus4.Va4.Va1
    _communication_bus4_va4_va1__out = (HIL_InFloat(0xc80000 + 0x7));
    // Generated from the component: Communication.Bus4.Va5.Va1
    _communication_bus4_va5_va1__out = (HIL_InFloat(0xc80000 + 0x8));
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.IQ
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.VQ
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.IQ
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.VQ
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.IQ
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.VQ
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.IQ
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.VQ
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.IQ
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.VQ
    // Generated from the component: Communication.Bus5.Va1.Va1
    _communication_bus5_va1_va1__out = (HIL_InFloat(0xc80000 + 0xc));
    // Generated from the component: Communication.Bus5.Va4.Va1
    _communication_bus5_va4_va1__out = (HIL_InFloat(0xc80000 + 0xd));
    // Generated from the component: Communication.Bus5.Va5.Va1
    _communication_bus5_va5_va1__out = (HIL_InFloat(0xc80000 + 0xe));
    // Generated from the component: Bus2.Bus Join1
    _bus2_bus_join1__out[0] = _bus2_on__out;
    _bus2_bus_join1__out[1] = _bus2_q_ref__out;
    // Generated from the component: Bus4.Bus Join1
    _bus4_bus_join1__out[0] = _bus4_on__out;
    _bus4_bus_join1__out[1] = _bus4_q_ref__out;
    // Generated from the component: Bus5.Bus Join1
    _bus5_bus_join1__out[0] = _bus5_on__out;
    _bus5_bus_join1__out[1] = _bus5_q_ref__out;
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.IQ_byte_swap
    _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[0] = _communication_bus2_line_2_1_sv_publisher2_iq__out[0];
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[1] = _communication_bus2_line_2_1_sv_publisher2_iq__out[1];
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[2] = _communication_bus2_line_2_1_sv_publisher2_iq__out[2];
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in[3] = _communication_bus2_line_2_1_sv_publisher2_iq__out[3];
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.VQ_byte_swap
    _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[0] = _communication_bus2_line_2_1_sv_publisher2_vq__out[0];
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[1] = _communication_bus2_line_2_1_sv_publisher2_vq__out[1];
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[2] = _communication_bus2_line_2_1_sv_publisher2_vq__out[2];
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in[3] = _communication_bus2_line_2_1_sv_publisher2_vq__out[3];
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.IQ_byte_swap
    _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[0] = _communication_bus2_line_2_3_sv_publisher2_iq__out[0];
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[1] = _communication_bus2_line_2_3_sv_publisher2_iq__out[1];
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[2] = _communication_bus2_line_2_3_sv_publisher2_iq__out[2];
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in[3] = _communication_bus2_line_2_3_sv_publisher2_iq__out[3];
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.VQ_byte_swap
    _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[0] = _communication_bus2_line_2_3_sv_publisher2_vq__out[0];
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[1] = _communication_bus2_line_2_3_sv_publisher2_vq__out[1];
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[2] = _communication_bus2_line_2_3_sv_publisher2_vq__out[2];
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in[3] = _communication_bus2_line_2_3_sv_publisher2_vq__out[3];
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.IQ_byte_swap
    _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[0] = _communication_bus2_line_2_4_sv_publisher2_iq__out[0];
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[1] = _communication_bus2_line_2_4_sv_publisher2_iq__out[1];
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[2] = _communication_bus2_line_2_4_sv_publisher2_iq__out[2];
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in[3] = _communication_bus2_line_2_4_sv_publisher2_iq__out[3];
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.VQ_byte_swap
    _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[0] = _communication_bus2_line_2_4_sv_publisher2_vq__out[0];
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[1] = _communication_bus2_line_2_4_sv_publisher2_vq__out[1];
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[2] = _communication_bus2_line_2_4_sv_publisher2_vq__out[2];
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in[3] = _communication_bus2_line_2_4_sv_publisher2_vq__out[3];
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.IQ_byte_swap
    _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[0] = _communication_bus2_line_2_5_sv_publisher2_iq__out[0];
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[1] = _communication_bus2_line_2_5_sv_publisher2_iq__out[1];
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[2] = _communication_bus2_line_2_5_sv_publisher2_iq__out[2];
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in[3] = _communication_bus2_line_2_5_sv_publisher2_iq__out[3];
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.VQ_byte_swap
    _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[0] = _communication_bus2_line_2_5_sv_publisher2_vq__out[0];
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[1] = _communication_bus2_line_2_5_sv_publisher2_vq__out[1];
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[2] = _communication_bus2_line_2_5_sv_publisher2_vq__out[2];
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in[3] = _communication_bus2_line_2_5_sv_publisher2_vq__out[3];
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.IQ_byte_swap
    _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[0] = _communication_bus2_line_2_6_sv_publisher2_iq__out[0];
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[1] = _communication_bus2_line_2_6_sv_publisher2_iq__out[1];
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[2] = _communication_bus2_line_2_6_sv_publisher2_iq__out[2];
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in[3] = _communication_bus2_line_2_6_sv_publisher2_iq__out[3];
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.VQ_byte_swap
    _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[0] = _communication_bus2_line_2_6_sv_publisher2_vq__out[0];
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[1] = _communication_bus2_line_2_6_sv_publisher2_vq__out[1];
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[2] = _communication_bus2_line_2_6_sv_publisher2_vq__out[2];
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in[3] = _communication_bus2_line_2_6_sv_publisher2_vq__out[3];
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Neutro
    _communication_bus2_neutro__out = _communication_bus2_va5_va1__out + _communication_bus2_va1_va1__out + _communication_bus2_va4_va1__out;
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.IQ_byte_swap
    _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[0] = _communication_bus4_line_4_2_sv_publisher2_iq__out[0];
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[1] = _communication_bus4_line_4_2_sv_publisher2_iq__out[1];
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[2] = _communication_bus4_line_4_2_sv_publisher2_iq__out[2];
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in[3] = _communication_bus4_line_4_2_sv_publisher2_iq__out[3];
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.VQ_byte_swap
    _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[0] = _communication_bus4_line_4_2_sv_publisher2_vq__out[0];
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[1] = _communication_bus4_line_4_2_sv_publisher2_vq__out[1];
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[2] = _communication_bus4_line_4_2_sv_publisher2_vq__out[2];
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in[3] = _communication_bus4_line_4_2_sv_publisher2_vq__out[3];
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.IQ_byte_swap
    _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[0] = _communication_bus4_line_4_5_sv_publisher2_iq__out[0];
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[1] = _communication_bus4_line_4_5_sv_publisher2_iq__out[1];
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[2] = _communication_bus4_line_4_5_sv_publisher2_iq__out[2];
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in[3] = _communication_bus4_line_4_5_sv_publisher2_iq__out[3];
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.VQ_byte_swap
    _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[0] = _communication_bus4_line_4_5_sv_publisher2_vq__out[0];
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[1] = _communication_bus4_line_4_5_sv_publisher2_vq__out[1];
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[2] = _communication_bus4_line_4_5_sv_publisher2_vq__out[2];
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in[3] = _communication_bus4_line_4_5_sv_publisher2_vq__out[3];
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Sum1
    _communication_bus4_sum1__out = _communication_bus4_va5_va1__out + _communication_bus4_va1_va1__out + _communication_bus4_va4_va1__out;
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.IQ_byte_swap
    _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[0] = _communication_bus5_line_5_1_sv_publisher2_iq__out[0];
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[1] = _communication_bus5_line_5_1_sv_publisher2_iq__out[1];
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[2] = _communication_bus5_line_5_1_sv_publisher2_iq__out[2];
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in[3] = _communication_bus5_line_5_1_sv_publisher2_iq__out[3];
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.VQ_byte_swap
    _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[0] = _communication_bus5_line_5_1_sv_publisher2_vq__out[0];
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[1] = _communication_bus5_line_5_1_sv_publisher2_vq__out[1];
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[2] = _communication_bus5_line_5_1_sv_publisher2_vq__out[2];
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in[3] = _communication_bus5_line_5_1_sv_publisher2_vq__out[3];
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.IQ_byte_swap
    _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[0] = _communication_bus5_line_5_2_sv_publisher2_iq__out[0];
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[1] = _communication_bus5_line_5_2_sv_publisher2_iq__out[1];
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[2] = _communication_bus5_line_5_2_sv_publisher2_iq__out[2];
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in[3] = _communication_bus5_line_5_2_sv_publisher2_iq__out[3];
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.VQ_byte_swap
    _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[0] = _communication_bus5_line_5_2_sv_publisher2_vq__out[0];
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[1] = _communication_bus5_line_5_2_sv_publisher2_vq__out[1];
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[2] = _communication_bus5_line_5_2_sv_publisher2_vq__out[2];
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in[3] = _communication_bus5_line_5_2_sv_publisher2_vq__out[3];
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.IQ_byte_swap
    _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[0] = _communication_bus5_line_5_3_sv_publisher2_iq__out[0];
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[1] = _communication_bus5_line_5_3_sv_publisher2_iq__out[1];
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[2] = _communication_bus5_line_5_3_sv_publisher2_iq__out[2];
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in[3] = _communication_bus5_line_5_3_sv_publisher2_iq__out[3];
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.VQ_byte_swap
    _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[0] = _communication_bus5_line_5_3_sv_publisher2_vq__out[0];
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[1] = _communication_bus5_line_5_3_sv_publisher2_vq__out[1];
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[2] = _communication_bus5_line_5_3_sv_publisher2_vq__out[2];
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in[3] = _communication_bus5_line_5_3_sv_publisher2_vq__out[3];
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.IQ_byte_swap
    _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[0] = _communication_bus5_line_5_4_sv_publisher2_iq__out[0];
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[1] = _communication_bus5_line_5_4_sv_publisher2_iq__out[1];
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[2] = _communication_bus5_line_5_4_sv_publisher2_iq__out[2];
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in[3] = _communication_bus5_line_5_4_sv_publisher2_iq__out[3];
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.VQ_byte_swap
    _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[0] = _communication_bus5_line_5_4_sv_publisher2_vq__out[0];
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[1] = _communication_bus5_line_5_4_sv_publisher2_vq__out[1];
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[2] = _communication_bus5_line_5_4_sv_publisher2_vq__out[2];
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in[3] = _communication_bus5_line_5_4_sv_publisher2_vq__out[3];
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.IQ_byte_swap
    _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[0] = _communication_bus5_line_5_6_sv_publisher2_iq__out[0];
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr0;
    _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[1] = _communication_bus5_line_5_6_sv_publisher2_iq__out[1];
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr1;
    _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[2] = _communication_bus5_line_5_6_sv_publisher2_iq__out[2];
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr2;
    _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in[3] = _communication_bus5_line_5_6_sv_publisher2_iq__out[3];
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.VQ_byte_swap
    _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[0] = _communication_bus5_line_5_6_sv_publisher2_vq__out[0];
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr0) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr0;
    _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[1] = _communication_bus5_line_5_6_sv_publisher2_vq__out[1];
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr1) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr1;
    _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[2] = _communication_bus5_line_5_6_sv_publisher2_vq__out[2];
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr2) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr2;
    _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in[3] = _communication_bus5_line_5_6_sv_publisher2_vq__out[3];
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr3) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Sum1
    _communication_bus5_sum1__out = _communication_bus5_va5_va1__out + _communication_bus5_va1_va1__out + _communication_bus5_va4_va1__out;
    // Generated from the component: Bus Join1
    _bus_join1__out[0] = _bus4_bus_join1__out[0];
    _bus_join1__out[1] = _bus4_bus_join1__out[1];
    _bus_join1__out[2] = _bus5_bus_join1__out[0];
    _bus_join1__out[3] = _bus5_bus_join1__out[1];
    _bus_join1__out[4] = _bus2_bus_join1__out[0];
    _bus_join1__out[5] = _bus2_bus_join1__out[1];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.IQ_bus_split
    _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out = _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out1 = _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out2 = _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out3 = _communication_bus2_line_2_1_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.VQ_bus_split
    _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out = _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out1 = _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out2 = _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out3 = _communication_bus2_line_2_1_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.IQ_bus_split
    _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out = _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out1 = _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out2 = _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out3 = _communication_bus2_line_2_3_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.VQ_bus_split
    _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out = _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out1 = _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out2 = _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out3 = _communication_bus2_line_2_3_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.IQ_bus_split
    _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out = _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out1 = _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out2 = _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out3 = _communication_bus2_line_2_4_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.VQ_bus_split
    _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out = _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out1 = _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out2 = _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out3 = _communication_bus2_line_2_4_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.IQ_bus_split
    _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out = _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out1 = _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out2 = _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out3 = _communication_bus2_line_2_5_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.VQ_bus_split
    _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out = _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out1 = _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out2 = _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out3 = _communication_bus2_line_2_5_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.IQ_bus_split
    _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out = _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out1 = _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out2 = _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out3 = _communication_bus2_line_2_6_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.VQ_bus_split
    _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out = _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out1 = _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out2 = _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out3 = _communication_bus2_line_2_6_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Bus Join1
    _communication_bus2_bus_join1__out[0] = _communication_bus2_va5_va1__out;
    _communication_bus2_bus_join1__out[1] = _communication_bus2_va4_va1__out;
    _communication_bus2_bus_join1__out[2] = _communication_bus2_va1_va1__out;
    _communication_bus2_bus_join1__out[3] = _communication_bus2_neutro__out;
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.IQ_bus_split
    _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out = _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out1 = _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out2 = _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out3 = _communication_bus4_line_4_2_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.VQ_bus_split
    _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out = _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out1 = _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out2 = _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out3 = _communication_bus4_line_4_2_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.IQ_bus_split
    _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out = _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out1 = _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out2 = _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out3 = _communication_bus4_line_4_5_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.VQ_bus_split
    _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out = _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out1 = _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out2 = _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out3 = _communication_bus4_line_4_5_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Bus Join1
    _communication_bus4_bus_join1__out[0] = _communication_bus4_va5_va1__out;
    _communication_bus4_bus_join1__out[1] = _communication_bus4_va4_va1__out;
    _communication_bus4_bus_join1__out[2] = _communication_bus4_va1_va1__out;
    _communication_bus4_bus_join1__out[3] = _communication_bus4_sum1__out;
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.IQ_bus_split
    _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out = _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out1 = _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out2 = _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out3 = _communication_bus5_line_5_1_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.VQ_bus_split
    _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out = _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out1 = _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out2 = _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out3 = _communication_bus5_line_5_1_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.IQ_bus_split
    _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out = _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out1 = _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out2 = _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out3 = _communication_bus5_line_5_2_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.VQ_bus_split
    _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out = _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out1 = _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out2 = _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out3 = _communication_bus5_line_5_2_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.IQ_bus_split
    _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out = _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out1 = _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out2 = _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out3 = _communication_bus5_line_5_3_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.VQ_bus_split
    _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out = _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out1 = _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out2 = _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out3 = _communication_bus5_line_5_3_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.IQ_bus_split
    _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out = _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out1 = _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out2 = _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out3 = _communication_bus5_line_5_4_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.VQ_bus_split
    _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out = _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out1 = _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out2 = _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out3 = _communication_bus5_line_5_4_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.IQ_bus_split
    _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out = _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[0];
    _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out1 = _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[1];
    _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out2 = _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[2];
    _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out3 = _communication_bus5_line_5_6_sv_publisher2_iq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.VQ_bus_split
    _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out = _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[0];
    _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out1 = _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[1];
    _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out2 = _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[2];
    _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out3 = _communication_bus5_line_5_6_sv_publisher2_vq_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Bus Join1
    _communication_bus5_bus_join1__out[0] = _communication_bus5_va5_va1__out;
    _communication_bus5_bus_join1__out[1] = _communication_bus5_va4_va1__out;
    _communication_bus5_bus_join1__out[2] = _communication_bus5_va1_va1__out;
    _communication_bus5_bus_join1__out[3] = _communication_bus5_sum1__out;
    // Generated from the component: PV_out.Bus Split1
    _pv_out_bus_split1__out[0] = _bus_join1__out[0];
    _pv_out_bus_split1__out[1] = _bus_join1__out[1];
    _pv_out_bus_split1__out1[0] = _bus_join1__out[2];
    _pv_out_bus_split1__out1[1] = _bus_join1__out[3];
    _pv_out_bus_split1__out2[0] = _bus_join1__out[4];
    _pv_out_bus_split1__out2[1] = _bus_join1__out[5];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.I_scale
    _communication_bus2_line_2_1_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_1_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_1_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_1_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.V_scale
    _communication_bus2_line_2_1_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_1_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_1_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_1_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.I_scale
    _communication_bus2_line_2_3_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_3_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_3_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_3_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.V_scale
    _communication_bus2_line_2_3_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_3_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_3_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_3_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.I_scale
    _communication_bus2_line_2_4_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_4_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_4_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_4_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.V_scale
    _communication_bus2_line_2_4_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_4_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_4_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_4_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.I_scale
    _communication_bus2_line_2_5_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_5_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_5_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_5_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.V_scale
    _communication_bus2_line_2_5_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_5_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_5_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_5_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.I_scale
    _communication_bus2_line_2_6_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_6_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_6_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_6_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.V_scale
    _communication_bus2_line_2_6_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus2_bus_join1__out[0];
    _communication_bus2_line_2_6_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus2_bus_join1__out[1];
    _communication_bus2_line_2_6_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus2_bus_join1__out[2];
    _communication_bus2_line_2_6_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus2_bus_join1__out[3];
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.I_scale
    _communication_bus4_line_4_2_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus4_bus_join1__out[0];
    _communication_bus4_line_4_2_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus4_bus_join1__out[1];
    _communication_bus4_line_4_2_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus4_bus_join1__out[2];
    _communication_bus4_line_4_2_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus4_bus_join1__out[3];
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.V_scale
    _communication_bus4_line_4_2_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus4_bus_join1__out[0];
    _communication_bus4_line_4_2_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus4_bus_join1__out[1];
    _communication_bus4_line_4_2_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus4_bus_join1__out[2];
    _communication_bus4_line_4_2_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus4_bus_join1__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.I_scale
    _communication_bus4_line_4_5_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus4_bus_join1__out[0];
    _communication_bus4_line_4_5_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus4_bus_join1__out[1];
    _communication_bus4_line_4_5_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus4_bus_join1__out[2];
    _communication_bus4_line_4_5_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus4_bus_join1__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.V_scale
    _communication_bus4_line_4_5_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus4_bus_join1__out[0];
    _communication_bus4_line_4_5_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus4_bus_join1__out[1];
    _communication_bus4_line_4_5_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus4_bus_join1__out[2];
    _communication_bus4_line_4_5_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus4_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.I_scale
    _communication_bus5_line_5_1_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_1_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_1_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_1_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.V_scale
    _communication_bus5_line_5_1_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_1_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_1_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_1_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.I_scale
    _communication_bus5_line_5_2_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_2_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_2_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_2_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.V_scale
    _communication_bus5_line_5_2_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_2_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_2_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_2_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.I_scale
    _communication_bus5_line_5_3_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_3_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_3_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_3_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.V_scale
    _communication_bus5_line_5_3_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_3_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_3_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_3_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.I_scale
    _communication_bus5_line_5_4_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_4_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_4_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_4_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.V_scale
    _communication_bus5_line_5_4_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_4_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_4_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_4_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.I_scale
    _communication_bus5_line_5_6_sv_publisher2_i_scale__out[0] = 1000.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_6_sv_publisher2_i_scale__out[1] = 1000.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_6_sv_publisher2_i_scale__out[2] = 1000.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_6_sv_publisher2_i_scale__out[3] = 1000.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.V_scale
    _communication_bus5_line_5_6_sv_publisher2_v_scale__out[0] = 100.0 * _communication_bus5_bus_join1__out[0];
    _communication_bus5_line_5_6_sv_publisher2_v_scale__out[1] = 100.0 * _communication_bus5_bus_join1__out[1];
    _communication_bus5_line_5_6_sv_publisher2_v_scale__out[2] = 100.0 * _communication_bus5_bus_join1__out[2];
    _communication_bus5_line_5_6_sv_publisher2_v_scale__out[3] = 100.0 * _communication_bus5_bus_join1__out[3];
    // Generated from the component: PV_out.Bus1
    HIL_OutAO(0x2009, (float)_pv_out_bus_split1__out2[0]);
    HIL_OutAO(0x200a, (float)_pv_out_bus_split1__out2[1]);
    // Generated from the component: PV_out.Bus3
    HIL_OutAO(0x200b, (float)_pv_out_bus_split1__out1[0]);
    HIL_OutAO(0x200c, (float)_pv_out_bus_split1__out1[1]);
    // Generated from the component: PV_out.Bus6
    HIL_OutAO(0x200d, (float)_pv_out_bus_split1__out[0]);
    HIL_OutAO(0x200e, (float)_pv_out_bus_split1__out[1]);
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.I_convert
    _communication_bus2_line_2_1_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_i_scale__out[0];
    _communication_bus2_line_2_1_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_i_scale__out[1];
    _communication_bus2_line_2_1_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_i_scale__out[2];
    _communication_bus2_line_2_1_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.V_convert
    _communication_bus2_line_2_1_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_v_scale__out[0];
    _communication_bus2_line_2_1_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_v_scale__out[1];
    _communication_bus2_line_2_1_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_v_scale__out[2];
    _communication_bus2_line_2_1_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus2_line_2_1_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.I_convert
    _communication_bus2_line_2_3_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_i_scale__out[0];
    _communication_bus2_line_2_3_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_i_scale__out[1];
    _communication_bus2_line_2_3_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_i_scale__out[2];
    _communication_bus2_line_2_3_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.V_convert
    _communication_bus2_line_2_3_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_v_scale__out[0];
    _communication_bus2_line_2_3_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_v_scale__out[1];
    _communication_bus2_line_2_3_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_v_scale__out[2];
    _communication_bus2_line_2_3_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus2_line_2_3_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.I_convert
    _communication_bus2_line_2_4_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_i_scale__out[0];
    _communication_bus2_line_2_4_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_i_scale__out[1];
    _communication_bus2_line_2_4_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_i_scale__out[2];
    _communication_bus2_line_2_4_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.V_convert
    _communication_bus2_line_2_4_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_v_scale__out[0];
    _communication_bus2_line_2_4_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_v_scale__out[1];
    _communication_bus2_line_2_4_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_v_scale__out[2];
    _communication_bus2_line_2_4_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus2_line_2_4_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.I_convert
    _communication_bus2_line_2_5_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_i_scale__out[0];
    _communication_bus2_line_2_5_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_i_scale__out[1];
    _communication_bus2_line_2_5_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_i_scale__out[2];
    _communication_bus2_line_2_5_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.V_convert
    _communication_bus2_line_2_5_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_v_scale__out[0];
    _communication_bus2_line_2_5_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_v_scale__out[1];
    _communication_bus2_line_2_5_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_v_scale__out[2];
    _communication_bus2_line_2_5_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus2_line_2_5_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.I_convert
    _communication_bus2_line_2_6_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_i_scale__out[0];
    _communication_bus2_line_2_6_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_i_scale__out[1];
    _communication_bus2_line_2_6_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_i_scale__out[2];
    _communication_bus2_line_2_6_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.V_convert
    _communication_bus2_line_2_6_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_v_scale__out[0];
    _communication_bus2_line_2_6_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_v_scale__out[1];
    _communication_bus2_line_2_6_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_v_scale__out[2];
    _communication_bus2_line_2_6_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus2_line_2_6_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.I_convert
    _communication_bus4_line_4_2_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_i_scale__out[0];
    _communication_bus4_line_4_2_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_i_scale__out[1];
    _communication_bus4_line_4_2_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_i_scale__out[2];
    _communication_bus4_line_4_2_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.V_convert
    _communication_bus4_line_4_2_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_v_scale__out[0];
    _communication_bus4_line_4_2_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_v_scale__out[1];
    _communication_bus4_line_4_2_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_v_scale__out[2];
    _communication_bus4_line_4_2_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus4_line_4_2_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.I_convert
    _communication_bus4_line_4_5_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_i_scale__out[0];
    _communication_bus4_line_4_5_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_i_scale__out[1];
    _communication_bus4_line_4_5_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_i_scale__out[2];
    _communication_bus4_line_4_5_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.V_convert
    _communication_bus4_line_4_5_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_v_scale__out[0];
    _communication_bus4_line_4_5_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_v_scale__out[1];
    _communication_bus4_line_4_5_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_v_scale__out[2];
    _communication_bus4_line_4_5_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus4_line_4_5_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.I_convert
    _communication_bus5_line_5_1_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_i_scale__out[0];
    _communication_bus5_line_5_1_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_i_scale__out[1];
    _communication_bus5_line_5_1_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_i_scale__out[2];
    _communication_bus5_line_5_1_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.V_convert
    _communication_bus5_line_5_1_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_v_scale__out[0];
    _communication_bus5_line_5_1_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_v_scale__out[1];
    _communication_bus5_line_5_1_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_v_scale__out[2];
    _communication_bus5_line_5_1_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus5_line_5_1_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.I_convert
    _communication_bus5_line_5_2_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_i_scale__out[0];
    _communication_bus5_line_5_2_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_i_scale__out[1];
    _communication_bus5_line_5_2_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_i_scale__out[2];
    _communication_bus5_line_5_2_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.V_convert
    _communication_bus5_line_5_2_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_v_scale__out[0];
    _communication_bus5_line_5_2_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_v_scale__out[1];
    _communication_bus5_line_5_2_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_v_scale__out[2];
    _communication_bus5_line_5_2_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus5_line_5_2_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.I_convert
    _communication_bus5_line_5_3_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_i_scale__out[0];
    _communication_bus5_line_5_3_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_i_scale__out[1];
    _communication_bus5_line_5_3_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_i_scale__out[2];
    _communication_bus5_line_5_3_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.V_convert
    _communication_bus5_line_5_3_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_v_scale__out[0];
    _communication_bus5_line_5_3_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_v_scale__out[1];
    _communication_bus5_line_5_3_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_v_scale__out[2];
    _communication_bus5_line_5_3_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus5_line_5_3_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.I_convert
    _communication_bus5_line_5_4_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_i_scale__out[0];
    _communication_bus5_line_5_4_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_i_scale__out[1];
    _communication_bus5_line_5_4_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_i_scale__out[2];
    _communication_bus5_line_5_4_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.V_convert
    _communication_bus5_line_5_4_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_v_scale__out[0];
    _communication_bus5_line_5_4_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_v_scale__out[1];
    _communication_bus5_line_5_4_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_v_scale__out[2];
    _communication_bus5_line_5_4_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus5_line_5_4_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.I_convert
    _communication_bus5_line_5_6_sv_publisher2_i_convert__out[0] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_i_scale__out[0];
    _communication_bus5_line_5_6_sv_publisher2_i_convert__out[1] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_i_scale__out[1];
    _communication_bus5_line_5_6_sv_publisher2_i_convert__out[2] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_i_scale__out[2];
    _communication_bus5_line_5_6_sv_publisher2_i_convert__out[3] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_i_scale__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.V_convert
    _communication_bus5_line_5_6_sv_publisher2_v_convert__out[0] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_v_scale__out[0];
    _communication_bus5_line_5_6_sv_publisher2_v_convert__out[1] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_v_scale__out[1];
    _communication_bus5_line_5_6_sv_publisher2_v_convert__out[2] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_v_scale__out[2];
    _communication_bus5_line_5_6_sv_publisher2_v_convert__out[3] = (X_Int32)_communication_bus5_line_5_6_sv_publisher2_v_scale__out[3];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.I_byte_swap
    _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[0] = _communication_bus2_line_2_1_sv_publisher2_i_convert__out[0];
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[1] = _communication_bus2_line_2_1_sv_publisher2_i_convert__out[1];
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[2] = _communication_bus2_line_2_1_sv_publisher2_i_convert__out[2];
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in[3] = _communication_bus2_line_2_1_sv_publisher2_i_convert__out[3];
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_1_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.V_byte_swap
    _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[0] = _communication_bus2_line_2_1_sv_publisher2_v_convert__out[0];
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[1] = _communication_bus2_line_2_1_sv_publisher2_v_convert__out[1];
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[2] = _communication_bus2_line_2_1_sv_publisher2_v_convert__out[2];
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in[3] = _communication_bus2_line_2_1_sv_publisher2_v_convert__out[3];
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_1_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.I_byte_swap
    _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[0] = _communication_bus2_line_2_3_sv_publisher2_i_convert__out[0];
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[1] = _communication_bus2_line_2_3_sv_publisher2_i_convert__out[1];
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[2] = _communication_bus2_line_2_3_sv_publisher2_i_convert__out[2];
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in[3] = _communication_bus2_line_2_3_sv_publisher2_i_convert__out[3];
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_3_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.V_byte_swap
    _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[0] = _communication_bus2_line_2_3_sv_publisher2_v_convert__out[0];
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[1] = _communication_bus2_line_2_3_sv_publisher2_v_convert__out[1];
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[2] = _communication_bus2_line_2_3_sv_publisher2_v_convert__out[2];
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in[3] = _communication_bus2_line_2_3_sv_publisher2_v_convert__out[3];
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_3_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.I_byte_swap
    _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[0] = _communication_bus2_line_2_4_sv_publisher2_i_convert__out[0];
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[1] = _communication_bus2_line_2_4_sv_publisher2_i_convert__out[1];
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[2] = _communication_bus2_line_2_4_sv_publisher2_i_convert__out[2];
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in[3] = _communication_bus2_line_2_4_sv_publisher2_i_convert__out[3];
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_4_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.V_byte_swap
    _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[0] = _communication_bus2_line_2_4_sv_publisher2_v_convert__out[0];
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[1] = _communication_bus2_line_2_4_sv_publisher2_v_convert__out[1];
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[2] = _communication_bus2_line_2_4_sv_publisher2_v_convert__out[2];
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in[3] = _communication_bus2_line_2_4_sv_publisher2_v_convert__out[3];
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_4_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.I_byte_swap
    _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[0] = _communication_bus2_line_2_5_sv_publisher2_i_convert__out[0];
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[1] = _communication_bus2_line_2_5_sv_publisher2_i_convert__out[1];
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[2] = _communication_bus2_line_2_5_sv_publisher2_i_convert__out[2];
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in[3] = _communication_bus2_line_2_5_sv_publisher2_i_convert__out[3];
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_5_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.V_byte_swap
    _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[0] = _communication_bus2_line_2_5_sv_publisher2_v_convert__out[0];
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[1] = _communication_bus2_line_2_5_sv_publisher2_v_convert__out[1];
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[2] = _communication_bus2_line_2_5_sv_publisher2_v_convert__out[2];
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in[3] = _communication_bus2_line_2_5_sv_publisher2_v_convert__out[3];
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_5_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.I_byte_swap
    _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[0] = _communication_bus2_line_2_6_sv_publisher2_i_convert__out[0];
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[1] = _communication_bus2_line_2_6_sv_publisher2_i_convert__out[1];
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[2] = _communication_bus2_line_2_6_sv_publisher2_i_convert__out[2];
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in[3] = _communication_bus2_line_2_6_sv_publisher2_i_convert__out[3];
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_6_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.V_byte_swap
    _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[0] = _communication_bus2_line_2_6_sv_publisher2_v_convert__out[0];
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[1] = _communication_bus2_line_2_6_sv_publisher2_v_convert__out[1];
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[2] = _communication_bus2_line_2_6_sv_publisher2_v_convert__out[2];
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in[3] = _communication_bus2_line_2_6_sv_publisher2_v_convert__out[3];
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus2_line_2_6_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.I_byte_swap
    _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[0] = _communication_bus4_line_4_2_sv_publisher2_i_convert__out[0];
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[1] = _communication_bus4_line_4_2_sv_publisher2_i_convert__out[1];
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[2] = _communication_bus4_line_4_2_sv_publisher2_i_convert__out[2];
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in[3] = _communication_bus4_line_4_2_sv_publisher2_i_convert__out[3];
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_2_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.V_byte_swap
    _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[0] = _communication_bus4_line_4_2_sv_publisher2_v_convert__out[0];
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[1] = _communication_bus4_line_4_2_sv_publisher2_v_convert__out[1];
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[2] = _communication_bus4_line_4_2_sv_publisher2_v_convert__out[2];
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in[3] = _communication_bus4_line_4_2_sv_publisher2_v_convert__out[3];
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_2_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.I_byte_swap
    _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[0] = _communication_bus4_line_4_5_sv_publisher2_i_convert__out[0];
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[1] = _communication_bus4_line_4_5_sv_publisher2_i_convert__out[1];
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[2] = _communication_bus4_line_4_5_sv_publisher2_i_convert__out[2];
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in[3] = _communication_bus4_line_4_5_sv_publisher2_i_convert__out[3];
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_5_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.V_byte_swap
    _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[0] = _communication_bus4_line_4_5_sv_publisher2_v_convert__out[0];
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[1] = _communication_bus4_line_4_5_sv_publisher2_v_convert__out[1];
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[2] = _communication_bus4_line_4_5_sv_publisher2_v_convert__out[2];
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in[3] = _communication_bus4_line_4_5_sv_publisher2_v_convert__out[3];
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus4_line_4_5_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.I_byte_swap
    _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[0] = _communication_bus5_line_5_1_sv_publisher2_i_convert__out[0];
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[1] = _communication_bus5_line_5_1_sv_publisher2_i_convert__out[1];
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[2] = _communication_bus5_line_5_1_sv_publisher2_i_convert__out[2];
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in[3] = _communication_bus5_line_5_1_sv_publisher2_i_convert__out[3];
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_1_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.V_byte_swap
    _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[0] = _communication_bus5_line_5_1_sv_publisher2_v_convert__out[0];
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[1] = _communication_bus5_line_5_1_sv_publisher2_v_convert__out[1];
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[2] = _communication_bus5_line_5_1_sv_publisher2_v_convert__out[2];
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in[3] = _communication_bus5_line_5_1_sv_publisher2_v_convert__out[3];
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_1_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.I_byte_swap
    _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[0] = _communication_bus5_line_5_2_sv_publisher2_i_convert__out[0];
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[1] = _communication_bus5_line_5_2_sv_publisher2_i_convert__out[1];
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[2] = _communication_bus5_line_5_2_sv_publisher2_i_convert__out[2];
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in[3] = _communication_bus5_line_5_2_sv_publisher2_i_convert__out[3];
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_2_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.V_byte_swap
    _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[0] = _communication_bus5_line_5_2_sv_publisher2_v_convert__out[0];
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[1] = _communication_bus5_line_5_2_sv_publisher2_v_convert__out[1];
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[2] = _communication_bus5_line_5_2_sv_publisher2_v_convert__out[2];
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in[3] = _communication_bus5_line_5_2_sv_publisher2_v_convert__out[3];
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_2_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.I_byte_swap
    _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[0] = _communication_bus5_line_5_3_sv_publisher2_i_convert__out[0];
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[1] = _communication_bus5_line_5_3_sv_publisher2_i_convert__out[1];
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[2] = _communication_bus5_line_5_3_sv_publisher2_i_convert__out[2];
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in[3] = _communication_bus5_line_5_3_sv_publisher2_i_convert__out[3];
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_3_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.V_byte_swap
    _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[0] = _communication_bus5_line_5_3_sv_publisher2_v_convert__out[0];
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[1] = _communication_bus5_line_5_3_sv_publisher2_v_convert__out[1];
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[2] = _communication_bus5_line_5_3_sv_publisher2_v_convert__out[2];
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in[3] = _communication_bus5_line_5_3_sv_publisher2_v_convert__out[3];
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_3_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.I_byte_swap
    _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[0] = _communication_bus5_line_5_4_sv_publisher2_i_convert__out[0];
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[1] = _communication_bus5_line_5_4_sv_publisher2_i_convert__out[1];
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[2] = _communication_bus5_line_5_4_sv_publisher2_i_convert__out[2];
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in[3] = _communication_bus5_line_5_4_sv_publisher2_i_convert__out[3];
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_4_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.V_byte_swap
    _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[0] = _communication_bus5_line_5_4_sv_publisher2_v_convert__out[0];
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[1] = _communication_bus5_line_5_4_sv_publisher2_v_convert__out[1];
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[2] = _communication_bus5_line_5_4_sv_publisher2_v_convert__out[2];
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in[3] = _communication_bus5_line_5_4_sv_publisher2_v_convert__out[3];
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_4_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.I_byte_swap
    _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[0] = _communication_bus5_line_5_6_sv_publisher2_i_convert__out[0];
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr0) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr0;
    _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[1] = _communication_bus5_line_5_6_sv_publisher2_i_convert__out[1];
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr1) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr1;
    _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[2] = _communication_bus5_line_5_6_sv_publisher2_i_convert__out[2];
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr2) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr2;
    _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in[3] = _communication_bus5_line_5_6_sv_publisher2_i_convert__out[3];
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr3) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_6_sv_publisher2_i_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.V_byte_swap
    _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[0] = _communication_bus5_line_5_6_sv_publisher2_v_convert__out[0];
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr0) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr0 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr0 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr0 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr0 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr0 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr0 + 3) = *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr0;
    _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[1] = _communication_bus5_line_5_6_sv_publisher2_v_convert__out[1];
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr1) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr1 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr1 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr1 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr1 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr1 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr1 + 3) = *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr1;
    _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[2] = _communication_bus5_line_5_6_sv_publisher2_v_convert__out[2];
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr2) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr2 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr2 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr2 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr2 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr2 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr2 + 3) = *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr2;
    _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in[3] = _communication_bus5_line_5_6_sv_publisher2_v_convert__out[3];
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr3) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr3 + 3);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr3 + 1) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr3 + 2);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr3 + 2) = *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr3 + 1);
    *(_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out_ptr3 + 3) = *_communication_bus5_line_5_6_sv_publisher2_v_byte_swap__in_ptr3;
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.I_bus_split
    _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out = _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[0];
    _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out1 = _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[1];
    _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out2 = _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[2];
    _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out3 = _communication_bus2_line_2_1_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.V_bus_split
    _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out = _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[0];
    _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out1 = _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[1];
    _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out2 = _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[2];
    _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out3 = _communication_bus2_line_2_1_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.I_bus_split
    _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out = _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[0];
    _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out1 = _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[1];
    _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out2 = _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[2];
    _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out3 = _communication_bus2_line_2_3_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.V_bus_split
    _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out = _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[0];
    _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out1 = _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[1];
    _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out2 = _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[2];
    _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out3 = _communication_bus2_line_2_3_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.I_bus_split
    _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out = _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[0];
    _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out1 = _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[1];
    _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out2 = _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[2];
    _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out3 = _communication_bus2_line_2_4_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.V_bus_split
    _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out = _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[0];
    _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out1 = _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[1];
    _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out2 = _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[2];
    _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out3 = _communication_bus2_line_2_4_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.I_bus_split
    _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out = _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[0];
    _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out1 = _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[1];
    _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out2 = _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[2];
    _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out3 = _communication_bus2_line_2_5_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.V_bus_split
    _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out = _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[0];
    _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out1 = _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[1];
    _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out2 = _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[2];
    _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out3 = _communication_bus2_line_2_5_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.I_bus_split
    _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out = _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[0];
    _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out1 = _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[1];
    _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out2 = _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[2];
    _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out3 = _communication_bus2_line_2_6_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.V_bus_split
    _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out = _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[0];
    _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out1 = _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[1];
    _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out2 = _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[2];
    _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out3 = _communication_bus2_line_2_6_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.I_bus_split
    _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out = _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[0];
    _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out1 = _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[1];
    _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out2 = _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[2];
    _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out3 = _communication_bus4_line_4_2_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.V_bus_split
    _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out = _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[0];
    _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out1 = _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[1];
    _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out2 = _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[2];
    _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out3 = _communication_bus4_line_4_2_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.I_bus_split
    _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out = _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[0];
    _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out1 = _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[1];
    _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out2 = _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[2];
    _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out3 = _communication_bus4_line_4_5_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.V_bus_split
    _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out = _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[0];
    _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out1 = _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[1];
    _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out2 = _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[2];
    _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out3 = _communication_bus4_line_4_5_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.I_bus_split
    _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out = _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[0];
    _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out1 = _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[1];
    _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out2 = _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[2];
    _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out3 = _communication_bus5_line_5_1_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.V_bus_split
    _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out = _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[0];
    _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out1 = _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[1];
    _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out2 = _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[2];
    _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out3 = _communication_bus5_line_5_1_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.I_bus_split
    _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out = _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[0];
    _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out1 = _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[1];
    _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out2 = _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[2];
    _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out3 = _communication_bus5_line_5_2_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.V_bus_split
    _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out = _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[0];
    _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out1 = _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[1];
    _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out2 = _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[2];
    _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out3 = _communication_bus5_line_5_2_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.I_bus_split
    _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out = _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[0];
    _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out1 = _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[1];
    _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out2 = _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[2];
    _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out3 = _communication_bus5_line_5_3_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.V_bus_split
    _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out = _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[0];
    _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out1 = _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[1];
    _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out2 = _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[2];
    _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out3 = _communication_bus5_line_5_3_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.I_bus_split
    _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out = _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[0];
    _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out1 = _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[1];
    _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out2 = _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[2];
    _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out3 = _communication_bus5_line_5_4_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.V_bus_split
    _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out = _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[0];
    _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out1 = _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[1];
    _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out2 = _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[2];
    _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out3 = _communication_bus5_line_5_4_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.I_bus_split
    _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out = _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[0];
    _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out1 = _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[1];
    _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out2 = _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[2];
    _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out3 = _communication_bus5_line_5_6_sv_publisher2_i_byte_swap__out[3];
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.V_bus_split
    _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out = _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[0];
    _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out1 = _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[1];
    _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out2 = _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[2];
    _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out3 = _communication_bus5_line_5_6_sv_publisher2_v_byte_swap__out[3];
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.bus_join
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[0] = _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[1] = _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[2] = _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out1;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[3] = _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out1;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[4] = _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out2;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[5] = _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out2;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[6] = _communication_bus2_line_2_1_sv_publisher2_i_bus_split__out3;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[7] = _communication_bus2_line_2_1_sv_publisher2_iq_bus_split__out3;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[8] = _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[9] = _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[10] = _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out1;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[11] = _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out1;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[12] = _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out2;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[13] = _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out2;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[14] = _communication_bus2_line_2_1_sv_publisher2_v_bus_split__out3;
    _communication_bus2_line_2_1_sv_publisher2_bus_join__out[15] = _communication_bus2_line_2_1_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.bus_join
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[0] = _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[1] = _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[2] = _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out1;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[3] = _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out1;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[4] = _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out2;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[5] = _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out2;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[6] = _communication_bus2_line_2_3_sv_publisher2_i_bus_split__out3;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[7] = _communication_bus2_line_2_3_sv_publisher2_iq_bus_split__out3;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[8] = _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[9] = _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[10] = _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out1;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[11] = _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out1;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[12] = _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out2;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[13] = _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out2;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[14] = _communication_bus2_line_2_3_sv_publisher2_v_bus_split__out3;
    _communication_bus2_line_2_3_sv_publisher2_bus_join__out[15] = _communication_bus2_line_2_3_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.bus_join
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[0] = _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[1] = _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[2] = _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out1;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[3] = _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out1;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[4] = _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out2;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[5] = _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out2;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[6] = _communication_bus2_line_2_4_sv_publisher2_i_bus_split__out3;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[7] = _communication_bus2_line_2_4_sv_publisher2_iq_bus_split__out3;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[8] = _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[9] = _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[10] = _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out1;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[11] = _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out1;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[12] = _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out2;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[13] = _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out2;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[14] = _communication_bus2_line_2_4_sv_publisher2_v_bus_split__out3;
    _communication_bus2_line_2_4_sv_publisher2_bus_join__out[15] = _communication_bus2_line_2_4_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.bus_join
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[0] = _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[1] = _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[2] = _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out1;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[3] = _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out1;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[4] = _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out2;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[5] = _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out2;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[6] = _communication_bus2_line_2_5_sv_publisher2_i_bus_split__out3;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[7] = _communication_bus2_line_2_5_sv_publisher2_iq_bus_split__out3;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[8] = _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[9] = _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[10] = _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out1;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[11] = _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out1;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[12] = _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out2;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[13] = _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out2;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[14] = _communication_bus2_line_2_5_sv_publisher2_v_bus_split__out3;
    _communication_bus2_line_2_5_sv_publisher2_bus_join__out[15] = _communication_bus2_line_2_5_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.bus_join
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[0] = _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[1] = _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[2] = _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out1;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[3] = _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out1;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[4] = _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out2;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[5] = _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out2;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[6] = _communication_bus2_line_2_6_sv_publisher2_i_bus_split__out3;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[7] = _communication_bus2_line_2_6_sv_publisher2_iq_bus_split__out3;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[8] = _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[9] = _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[10] = _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out1;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[11] = _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out1;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[12] = _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out2;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[13] = _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out2;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[14] = _communication_bus2_line_2_6_sv_publisher2_v_bus_split__out3;
    _communication_bus2_line_2_6_sv_publisher2_bus_join__out[15] = _communication_bus2_line_2_6_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.bus_join
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[0] = _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[1] = _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[2] = _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out1;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[3] = _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out1;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[4] = _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out2;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[5] = _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out2;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[6] = _communication_bus4_line_4_2_sv_publisher2_i_bus_split__out3;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[7] = _communication_bus4_line_4_2_sv_publisher2_iq_bus_split__out3;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[8] = _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[9] = _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[10] = _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out1;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[11] = _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out1;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[12] = _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out2;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[13] = _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out2;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[14] = _communication_bus4_line_4_2_sv_publisher2_v_bus_split__out3;
    _communication_bus4_line_4_2_sv_publisher2_bus_join__out[15] = _communication_bus4_line_4_2_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.bus_join
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[0] = _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[1] = _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[2] = _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out1;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[3] = _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out1;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[4] = _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out2;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[5] = _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out2;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[6] = _communication_bus4_line_4_5_sv_publisher2_i_bus_split__out3;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[7] = _communication_bus4_line_4_5_sv_publisher2_iq_bus_split__out3;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[8] = _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[9] = _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[10] = _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out1;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[11] = _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out1;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[12] = _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out2;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[13] = _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out2;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[14] = _communication_bus4_line_4_5_sv_publisher2_v_bus_split__out3;
    _communication_bus4_line_4_5_sv_publisher2_bus_join__out[15] = _communication_bus4_line_4_5_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.bus_join
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[0] = _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[1] = _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[2] = _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out1;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[3] = _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out1;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[4] = _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out2;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[5] = _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out2;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[6] = _communication_bus5_line_5_1_sv_publisher2_i_bus_split__out3;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[7] = _communication_bus5_line_5_1_sv_publisher2_iq_bus_split__out3;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[8] = _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[9] = _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[10] = _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out1;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[11] = _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out1;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[12] = _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out2;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[13] = _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out2;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[14] = _communication_bus5_line_5_1_sv_publisher2_v_bus_split__out3;
    _communication_bus5_line_5_1_sv_publisher2_bus_join__out[15] = _communication_bus5_line_5_1_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.bus_join
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[0] = _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[1] = _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[2] = _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out1;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[3] = _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out1;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[4] = _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out2;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[5] = _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out2;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[6] = _communication_bus5_line_5_2_sv_publisher2_i_bus_split__out3;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[7] = _communication_bus5_line_5_2_sv_publisher2_iq_bus_split__out3;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[8] = _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[9] = _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[10] = _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out1;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[11] = _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out1;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[12] = _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out2;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[13] = _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out2;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[14] = _communication_bus5_line_5_2_sv_publisher2_v_bus_split__out3;
    _communication_bus5_line_5_2_sv_publisher2_bus_join__out[15] = _communication_bus5_line_5_2_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.bus_join
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[0] = _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[1] = _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[2] = _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out1;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[3] = _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out1;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[4] = _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out2;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[5] = _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out2;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[6] = _communication_bus5_line_5_3_sv_publisher2_i_bus_split__out3;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[7] = _communication_bus5_line_5_3_sv_publisher2_iq_bus_split__out3;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[8] = _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[9] = _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[10] = _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out1;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[11] = _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out1;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[12] = _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out2;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[13] = _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out2;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[14] = _communication_bus5_line_5_3_sv_publisher2_v_bus_split__out3;
    _communication_bus5_line_5_3_sv_publisher2_bus_join__out[15] = _communication_bus5_line_5_3_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.bus_join
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[0] = _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[1] = _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[2] = _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out1;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[3] = _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out1;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[4] = _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out2;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[5] = _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out2;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[6] = _communication_bus5_line_5_4_sv_publisher2_i_bus_split__out3;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[7] = _communication_bus5_line_5_4_sv_publisher2_iq_bus_split__out3;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[8] = _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[9] = _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[10] = _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out1;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[11] = _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out1;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[12] = _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out2;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[13] = _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out2;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[14] = _communication_bus5_line_5_4_sv_publisher2_v_bus_split__out3;
    _communication_bus5_line_5_4_sv_publisher2_bus_join__out[15] = _communication_bus5_line_5_4_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.bus_join
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[0] = _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[1] = _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[2] = _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out1;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[3] = _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out1;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[4] = _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out2;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[5] = _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out2;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[6] = _communication_bus5_line_5_6_sv_publisher2_i_bus_split__out3;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[7] = _communication_bus5_line_5_6_sv_publisher2_iq_bus_split__out3;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[8] = _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[9] = _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[10] = _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out1;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[11] = _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out1;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[12] = _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out2;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[13] = _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out2;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[14] = _communication_bus5_line_5_6_sv_publisher2_v_bus_split__out3;
    _communication_bus5_line_5_6_sv_publisher2_bus_join__out[15] = _communication_bus5_line_5_6_sv_publisher2_vq_bus_split__out3;
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.SV_data
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Communication.Bus2.Line 2-1.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-3.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-4.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-5.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus2.Line 2-6.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus4.Line 4-2.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus4.Line 4-5.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-1.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-2.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-3.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-4.SV Publisher2.SV_data
    // Generated from the component: Communication.Bus5.Line 5-6.SV Publisher2.SV_data
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------