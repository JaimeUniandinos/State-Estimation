# Vincular PF
import sys
sys.path.append(r"E:\Program Files\DIgSILENT\PowerFactory 2020 SP2A\Python\3.8")


# import  PowerFactory  module
import powerfactory
# start PowerFactory  in engine  mode
app = powerfactory.GetApplication()
print(app)

user = app.GetCurrentUser()

# activate project
project = app.ActivateProject("6 busSystem")

prj = app.GetActiveProject()
print(prj)

ldf = app.GetFromStudyCase("ComLdf")
print(ldf)
ini = app.GetFromStudyCase('ComInc')
sim = app.GetFromStudyCase('ComSim')
Shc_folder = app.GetFromStudyCase('IntEvt')

terminals = app.GetCalcRelevantObjects("*.ElmTerm")
lines = app.GetCalcRelevantObjects("*.ElmTerm")
syms = app.GetCalcRelevantObjects("*.ElmSym")


Shc_folder.CreateObject('EvtSwitch', 'evento de generacion')
EventSet = Shc_folder.GetContents()
evt = EventSet[0]

evt.time =1.0

#evt.p_target = syms[1]

ldf.iopt_net = 0

ldf.Execute()

elmres = app.GetFromStudyCase('Results.ElmRes')

for terminal in terminals:
    elmres.AddVars(terminal,'m:u','m:phiu','m:fehz')

for sym in syms:
    elmres.AddVars(sym,'s:xspeed')

    
ini.Execute()
sim.Execute()

evt.Delete()

comres = app.GetFromStudyCase('ComRes')
comres.iopt_csel = 0
comres.iopt_tsel = 0
comres.iopt_locn = 2
comres.ciopt_head = 1
comres.pResult=elmres
comres.f_name = r'C:\Users\ja.forero15\Documents\SIXBUS_SYSTEM\SIXBUS-system.csv'
comres.iopt_exp=4
comres.Execute()