// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------

#include "math.h"
#include <stdint.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"

// H files from Advanced C Function components

// Header files from additional sources (Advanced C Function)
// ----------------------------------------------------------------------------------------
// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines



































































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables


//@cmp.var.start
// variables
float _communication_bus2_vrms1_vinst_va1__out;
float _communication_bus2_vrms4_vinst_va1__out;
float _communication_bus2_vrms5_vinst_va1__out;
float _communication_bus4_vrms1_vinst_va1__out;
float _communication_bus4_vrms4_vinst_va1__out;
float _communication_bus4_vrms5_vinst_va1__out;
float _communication_bus5_vrms1_vinst_va1__out;
float _communication_bus5_vrms4_vinst_va1__out;
float _communication_bus5_vrms5_vinst_va1__out;
float _communication_bus2_vrms1_rms_calc_fast__var_eff_s;
float _communication_bus2_vrms1_rms_calc_fast__period;
X_UnInt8 _communication_bus2_vrms1_rms_calc_fast__var_zc;
float _communication_bus2_vrms1_rms_calc_fast__var_filt_old;
float _communication_bus2_vrms1_rms_calc_slow__var_rms;
float _communication_bus2_vrms4_rms_calc_fast__var_eff_s;
float _communication_bus2_vrms4_rms_calc_fast__period;
X_UnInt8 _communication_bus2_vrms4_rms_calc_fast__var_zc;
float _communication_bus2_vrms4_rms_calc_fast__var_filt_old;
float _communication_bus2_vrms4_rms_calc_slow__var_rms;
float _communication_bus2_vrms5_rms_calc_fast__var_eff_s;
float _communication_bus2_vrms5_rms_calc_fast__period;
X_UnInt8 _communication_bus2_vrms5_rms_calc_fast__var_zc;
float _communication_bus2_vrms5_rms_calc_fast__var_filt_old;
float _communication_bus2_vrms5_rms_calc_slow__var_rms;
float _communication_bus4_vrms1_rms_calc_fast__var_eff_s;
float _communication_bus4_vrms1_rms_calc_fast__period;
X_UnInt8 _communication_bus4_vrms1_rms_calc_fast__var_zc;
float _communication_bus4_vrms1_rms_calc_fast__var_filt_old;
float _communication_bus4_vrms1_rms_calc_slow__var_rms;
float _communication_bus4_vrms4_rms_calc_fast__var_eff_s;
float _communication_bus4_vrms4_rms_calc_fast__period;
X_UnInt8 _communication_bus4_vrms4_rms_calc_fast__var_zc;
float _communication_bus4_vrms4_rms_calc_fast__var_filt_old;
float _communication_bus4_vrms4_rms_calc_slow__var_rms;
float _communication_bus4_vrms5_rms_calc_fast__var_eff_s;
float _communication_bus4_vrms5_rms_calc_fast__period;
X_UnInt8 _communication_bus4_vrms5_rms_calc_fast__var_zc;
float _communication_bus4_vrms5_rms_calc_fast__var_filt_old;
float _communication_bus4_vrms5_rms_calc_slow__var_rms;
float _communication_bus5_vrms1_rms_calc_fast__var_eff_s;
float _communication_bus5_vrms1_rms_calc_fast__period;
X_UnInt8 _communication_bus5_vrms1_rms_calc_fast__var_zc;
float _communication_bus5_vrms1_rms_calc_fast__var_filt_old;
float _communication_bus5_vrms1_rms_calc_slow__var_rms;
float _communication_bus5_vrms4_rms_calc_fast__var_eff_s;
float _communication_bus5_vrms4_rms_calc_fast__period;
X_UnInt8 _communication_bus5_vrms4_rms_calc_fast__var_zc;
float _communication_bus5_vrms4_rms_calc_fast__var_filt_old;
float _communication_bus5_vrms4_rms_calc_slow__var_rms;
float _communication_bus5_vrms5_rms_calc_fast__var_eff_s;
float _communication_bus5_vrms5_rms_calc_fast__period;
X_UnInt8 _communication_bus5_vrms5_rms_calc_fast__var_zc;
float _communication_bus5_vrms5_rms_calc_fast__var_filt_old;
float _communication_bus5_vrms5_rms_calc_slow__var_rms;
//@cmp.var.end

//@cmp.svar.start
// state variables
float _communication_bus2_vrms1_rt1_output__out =  0.0;
float _communication_bus2_vrms1_rt2_output__out =  0.0;
float _communication_bus2_vrms4_rt1_output__out =  0.0;
float _communication_bus2_vrms4_rt2_output__out =  0.0;
float _communication_bus2_vrms5_rt1_output__out =  0.0;
float _communication_bus2_vrms5_rt2_output__out =  0.0;
float _communication_bus4_vrms1_rt1_output__out =  0.0;
float _communication_bus4_vrms1_rt2_output__out =  0.0;
float _communication_bus4_vrms4_rt1_output__out =  0.0;
float _communication_bus4_vrms4_rt2_output__out =  0.0;
float _communication_bus4_vrms5_rt1_output__out =  0.0;
float _communication_bus4_vrms5_rt2_output__out =  0.0;
float _communication_bus5_vrms1_rt1_output__out =  0.0;
float _communication_bus5_vrms1_rt2_output__out =  0.0;
float _communication_bus5_vrms4_rt1_output__out =  0.0;
float _communication_bus5_vrms4_rt2_output__out =  0.0;
float _communication_bus5_vrms5_rt1_output__out =  0.0;
float _communication_bus5_vrms5_rt2_output__out =  0.0;
float _communication_bus2_vrms1_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus2_vrms1_rms_calc_fast__pc_cnt_1_state;
float _communication_bus2_vrms1_rms_calc_fast__var_filt;
float _communication_bus2_vrms4_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus2_vrms4_rms_calc_fast__pc_cnt_1_state;
float _communication_bus2_vrms4_rms_calc_fast__var_filt;
float _communication_bus2_vrms5_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus2_vrms5_rms_calc_fast__pc_cnt_1_state;
float _communication_bus2_vrms5_rms_calc_fast__var_filt;
float _communication_bus4_vrms1_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus4_vrms1_rms_calc_fast__pc_cnt_1_state;
float _communication_bus4_vrms1_rms_calc_fast__var_filt;
float _communication_bus4_vrms4_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus4_vrms4_rms_calc_fast__pc_cnt_1_state;
float _communication_bus4_vrms4_rms_calc_fast__var_filt;
float _communication_bus4_vrms5_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus4_vrms5_rms_calc_fast__pc_cnt_1_state;
float _communication_bus4_vrms5_rms_calc_fast__var_filt;
float _communication_bus5_vrms1_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus5_vrms1_rms_calc_fast__pc_cnt_1_state;
float _communication_bus5_vrms1_rms_calc_fast__var_filt;
float _communication_bus5_vrms4_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus5_vrms4_rms_calc_fast__pc_cnt_1_state;
float _communication_bus5_vrms4_rms_calc_fast__var_filt;
float _communication_bus5_vrms5_rms_calc_fast__v_sq_sum_state;
X_UnInt32 _communication_bus5_vrms5_rms_calc_fast__pc_cnt_1_state;
float _communication_bus5_vrms5_rms_calc_fast__var_filt;
//@cmp.svar.end




// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_sys_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _communication_bus2_vrms1_rt1_output__out =  0.0;
    _communication_bus2_vrms1_rt2_output__out =  0.0;
    _communication_bus2_vrms4_rt1_output__out =  0.0;
    _communication_bus2_vrms4_rt2_output__out =  0.0;
    _communication_bus2_vrms5_rt1_output__out =  0.0;
    _communication_bus2_vrms5_rt2_output__out =  0.0;
    _communication_bus4_vrms1_rt1_output__out =  0.0;
    _communication_bus4_vrms1_rt2_output__out =  0.0;
    _communication_bus4_vrms4_rt1_output__out =  0.0;
    _communication_bus4_vrms4_rt2_output__out =  0.0;
    _communication_bus4_vrms5_rt1_output__out =  0.0;
    _communication_bus4_vrms5_rt2_output__out =  0.0;
    _communication_bus5_vrms1_rt1_output__out =  0.0;
    _communication_bus5_vrms1_rt2_output__out =  0.0;
    _communication_bus5_vrms4_rt1_output__out =  0.0;
    _communication_bus5_vrms4_rt2_output__out =  0.0;
    _communication_bus5_vrms5_rt1_output__out =  0.0;
    _communication_bus5_vrms5_rt2_output__out =  0.0;
    _communication_bus2_vrms1_rms_calc_fast__var_eff_s = 0;
    _communication_bus2_vrms1_rms_calc_fast__period = 0.0f;
    _communication_bus2_vrms1_rms_calc_fast__var_filt = 0.0f;
    _communication_bus2_vrms1_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus2_vrms1_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus2_vrms4_rms_calc_fast__var_eff_s = 0;
    _communication_bus2_vrms4_rms_calc_fast__period = 0.0f;
    _communication_bus2_vrms4_rms_calc_fast__var_filt = 0.0f;
    _communication_bus2_vrms4_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus2_vrms4_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus2_vrms5_rms_calc_fast__var_eff_s = 0;
    _communication_bus2_vrms5_rms_calc_fast__period = 0.0f;
    _communication_bus2_vrms5_rms_calc_fast__var_filt = 0.0f;
    _communication_bus2_vrms5_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus2_vrms5_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus4_vrms1_rms_calc_fast__var_eff_s = 0;
    _communication_bus4_vrms1_rms_calc_fast__period = 0.0f;
    _communication_bus4_vrms1_rms_calc_fast__var_filt = 0.0f;
    _communication_bus4_vrms1_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus4_vrms1_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus4_vrms4_rms_calc_fast__var_eff_s = 0;
    _communication_bus4_vrms4_rms_calc_fast__period = 0.0f;
    _communication_bus4_vrms4_rms_calc_fast__var_filt = 0.0f;
    _communication_bus4_vrms4_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus4_vrms4_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus4_vrms5_rms_calc_fast__var_eff_s = 0;
    _communication_bus4_vrms5_rms_calc_fast__period = 0.0f;
    _communication_bus4_vrms5_rms_calc_fast__var_filt = 0.0f;
    _communication_bus4_vrms5_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus4_vrms5_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus5_vrms1_rms_calc_fast__var_eff_s = 0;
    _communication_bus5_vrms1_rms_calc_fast__period = 0.0f;
    _communication_bus5_vrms1_rms_calc_fast__var_filt = 0.0f;
    _communication_bus5_vrms1_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus5_vrms1_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus5_vrms4_rms_calc_fast__var_eff_s = 0;
    _communication_bus5_vrms4_rms_calc_fast__period = 0.0f;
    _communication_bus5_vrms4_rms_calc_fast__var_filt = 0.0f;
    _communication_bus5_vrms4_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus5_vrms4_rms_calc_fast__pc_cnt_1_state = 0;
    _communication_bus5_vrms5_rms_calc_fast__var_eff_s = 0;
    _communication_bus5_vrms5_rms_calc_fast__period = 0.0f;
    _communication_bus5_vrms5_rms_calc_fast__var_filt = 0.0f;
    _communication_bus5_vrms5_rms_calc_fast__v_sq_sum_state = 0.0f;
    _communication_bus5_vrms5_rms_calc_fast__pc_cnt_1_state = 0;
    HIL_OutAO(0x2000, 0.0f);
    HIL_OutAO(0x2001, 0.0f);
    HIL_OutAO(0x2002, 0.0f);
    HIL_OutAO(0x2003, 0.0f);
    HIL_OutAO(0x2004, 0.0f);
    HIL_OutAO(0x2005, 0.0f);
    HIL_OutAO(0x2006, 0.0f);
    HIL_OutAO(0x2007, 0.0f);
    HIL_OutAO(0x2008, 0.0f);
    //@cmp.init.block.end
}

void ReInit_sp_scope_sys_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}


void sys_terminate_fmu_objects_cpu0_dev0(void) {
    return;
}
// generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_sys_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Communication.Bus2.Vrms1.Vinst.Va1
    _communication_bus2_vrms1_vinst_va1__out = (HIL_InFloat(0xc80000 + 0x3));
    // Generated from the component: Communication.Bus2.Vrms4.Vinst.Va1
    _communication_bus2_vrms4_vinst_va1__out = (HIL_InFloat(0xc80000 + 0x4));
    // Generated from the component: Communication.Bus2.Vrms5.Vinst.Va1
    _communication_bus2_vrms5_vinst_va1__out = (HIL_InFloat(0xc80000 + 0x5));
    // Generated from the component: Communication.Bus4.Vrms1.Vinst.Va1
    _communication_bus4_vrms1_vinst_va1__out = (HIL_InFloat(0xc80000 + 0x9));
    // Generated from the component: Communication.Bus4.Vrms4.Vinst.Va1
    _communication_bus4_vrms4_vinst_va1__out = (HIL_InFloat(0xc80000 + 0xa));
    // Generated from the component: Communication.Bus4.Vrms5.Vinst.Va1
    _communication_bus4_vrms5_vinst_va1__out = (HIL_InFloat(0xc80000 + 0xb));
    // Generated from the component: Communication.Bus5.Vrms1.Vinst.Va1
    _communication_bus5_vrms1_vinst_va1__out = (HIL_InFloat(0xc80000 + 0xf));
    // Generated from the component: Communication.Bus5.Vrms4.Vinst.Va1
    _communication_bus5_vrms4_vinst_va1__out = (HIL_InFloat(0xc80000 + 0x10));
    // Generated from the component: Communication.Bus5.Vrms5.Vinst.Va1
    _communication_bus5_vrms5_vinst_va1__out = (HIL_InFloat(0xc80000 + 0x11));
    // Generated from the component: Communication.Bus2.Vrms1.rms_calc_fast
    _communication_bus2_vrms1_rms_calc_fast__v_sq_sum_state = _communication_bus2_vrms1_rms_calc_fast__v_sq_sum_state + _communication_bus2_vrms1_vinst_va1__out * _communication_bus2_vrms1_vinst_va1__out;
    _communication_bus2_vrms1_rms_calc_fast__var_filt_old = _communication_bus2_vrms1_rms_calc_fast__var_filt;
    _communication_bus2_vrms1_rms_calc_fast__var_filt = (_communication_bus2_vrms1_rms_calc_fast__var_filt_old * 0.909 + _communication_bus2_vrms1_vinst_va1__out * 0.0909);
    if((_communication_bus2_vrms1_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus2_vrms1_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus2_vrms1_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus2_vrms1_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus2_vrms1_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus2_vrms1_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus2_vrms1_rms_calc_fast__var_eff_s = _communication_bus2_vrms1_rms_calc_fast__v_sq_sum_state;
        _communication_bus2_vrms1_rms_calc_fast__period = (float)_communication_bus2_vrms1_rms_calc_fast__pc_cnt_1_state;
        _communication_bus2_vrms1_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus2.Vrms1.sys1
    // Generated from the component: Communication.Bus2.Vrms4.rms_calc_fast
    _communication_bus2_vrms4_rms_calc_fast__v_sq_sum_state = _communication_bus2_vrms4_rms_calc_fast__v_sq_sum_state + _communication_bus2_vrms4_vinst_va1__out * _communication_bus2_vrms4_vinst_va1__out;
    _communication_bus2_vrms4_rms_calc_fast__var_filt_old = _communication_bus2_vrms4_rms_calc_fast__var_filt;
    _communication_bus2_vrms4_rms_calc_fast__var_filt = (_communication_bus2_vrms4_rms_calc_fast__var_filt_old * 0.909 + _communication_bus2_vrms4_vinst_va1__out * 0.0909);
    if((_communication_bus2_vrms4_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus2_vrms4_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus2_vrms4_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus2_vrms4_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus2_vrms4_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus2_vrms4_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus2_vrms4_rms_calc_fast__var_eff_s = _communication_bus2_vrms4_rms_calc_fast__v_sq_sum_state;
        _communication_bus2_vrms4_rms_calc_fast__period = (float)_communication_bus2_vrms4_rms_calc_fast__pc_cnt_1_state;
        _communication_bus2_vrms4_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus2.Vrms4.sys1
    // Generated from the component: Communication.Bus2.Vrms5.rms_calc_fast
    _communication_bus2_vrms5_rms_calc_fast__v_sq_sum_state = _communication_bus2_vrms5_rms_calc_fast__v_sq_sum_state + _communication_bus2_vrms5_vinst_va1__out * _communication_bus2_vrms5_vinst_va1__out;
    _communication_bus2_vrms5_rms_calc_fast__var_filt_old = _communication_bus2_vrms5_rms_calc_fast__var_filt;
    _communication_bus2_vrms5_rms_calc_fast__var_filt = (_communication_bus2_vrms5_rms_calc_fast__var_filt_old * 0.909 + _communication_bus2_vrms5_vinst_va1__out * 0.0909);
    if((_communication_bus2_vrms5_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus2_vrms5_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus2_vrms5_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus2_vrms5_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus2_vrms5_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus2_vrms5_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus2_vrms5_rms_calc_fast__var_eff_s = _communication_bus2_vrms5_rms_calc_fast__v_sq_sum_state;
        _communication_bus2_vrms5_rms_calc_fast__period = (float)_communication_bus2_vrms5_rms_calc_fast__pc_cnt_1_state;
        _communication_bus2_vrms5_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus2.Vrms5.sys1
    // Generated from the component: Communication.Bus4.Vrms1.rms_calc_fast
    _communication_bus4_vrms1_rms_calc_fast__v_sq_sum_state = _communication_bus4_vrms1_rms_calc_fast__v_sq_sum_state + _communication_bus4_vrms1_vinst_va1__out * _communication_bus4_vrms1_vinst_va1__out;
    _communication_bus4_vrms1_rms_calc_fast__var_filt_old = _communication_bus4_vrms1_rms_calc_fast__var_filt;
    _communication_bus4_vrms1_rms_calc_fast__var_filt = (_communication_bus4_vrms1_rms_calc_fast__var_filt_old * 0.909 + _communication_bus4_vrms1_vinst_va1__out * 0.0909);
    if((_communication_bus4_vrms1_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus4_vrms1_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus4_vrms1_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus4_vrms1_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus4_vrms1_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus4_vrms1_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus4_vrms1_rms_calc_fast__var_eff_s = _communication_bus4_vrms1_rms_calc_fast__v_sq_sum_state;
        _communication_bus4_vrms1_rms_calc_fast__period = (float)_communication_bus4_vrms1_rms_calc_fast__pc_cnt_1_state;
        _communication_bus4_vrms1_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus4.Vrms1.sys1
    // Generated from the component: Communication.Bus4.Vrms4.rms_calc_fast
    _communication_bus4_vrms4_rms_calc_fast__v_sq_sum_state = _communication_bus4_vrms4_rms_calc_fast__v_sq_sum_state + _communication_bus4_vrms4_vinst_va1__out * _communication_bus4_vrms4_vinst_va1__out;
    _communication_bus4_vrms4_rms_calc_fast__var_filt_old = _communication_bus4_vrms4_rms_calc_fast__var_filt;
    _communication_bus4_vrms4_rms_calc_fast__var_filt = (_communication_bus4_vrms4_rms_calc_fast__var_filt_old * 0.909 + _communication_bus4_vrms4_vinst_va1__out * 0.0909);
    if((_communication_bus4_vrms4_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus4_vrms4_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus4_vrms4_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus4_vrms4_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus4_vrms4_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus4_vrms4_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus4_vrms4_rms_calc_fast__var_eff_s = _communication_bus4_vrms4_rms_calc_fast__v_sq_sum_state;
        _communication_bus4_vrms4_rms_calc_fast__period = (float)_communication_bus4_vrms4_rms_calc_fast__pc_cnt_1_state;
        _communication_bus4_vrms4_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus4.Vrms4.sys1
    // Generated from the component: Communication.Bus4.Vrms5.rms_calc_fast
    _communication_bus4_vrms5_rms_calc_fast__v_sq_sum_state = _communication_bus4_vrms5_rms_calc_fast__v_sq_sum_state + _communication_bus4_vrms5_vinst_va1__out * _communication_bus4_vrms5_vinst_va1__out;
    _communication_bus4_vrms5_rms_calc_fast__var_filt_old = _communication_bus4_vrms5_rms_calc_fast__var_filt;
    _communication_bus4_vrms5_rms_calc_fast__var_filt = (_communication_bus4_vrms5_rms_calc_fast__var_filt_old * 0.909 + _communication_bus4_vrms5_vinst_va1__out * 0.0909);
    if((_communication_bus4_vrms5_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus4_vrms5_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus4_vrms5_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus4_vrms5_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus4_vrms5_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus4_vrms5_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus4_vrms5_rms_calc_fast__var_eff_s = _communication_bus4_vrms5_rms_calc_fast__v_sq_sum_state;
        _communication_bus4_vrms5_rms_calc_fast__period = (float)_communication_bus4_vrms5_rms_calc_fast__pc_cnt_1_state;
        _communication_bus4_vrms5_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus4.Vrms5.sys1
    // Generated from the component: Communication.Bus5.Vrms1.rms_calc_fast
    _communication_bus5_vrms1_rms_calc_fast__v_sq_sum_state = _communication_bus5_vrms1_rms_calc_fast__v_sq_sum_state + _communication_bus5_vrms1_vinst_va1__out * _communication_bus5_vrms1_vinst_va1__out;
    _communication_bus5_vrms1_rms_calc_fast__var_filt_old = _communication_bus5_vrms1_rms_calc_fast__var_filt;
    _communication_bus5_vrms1_rms_calc_fast__var_filt = (_communication_bus5_vrms1_rms_calc_fast__var_filt_old * 0.909 + _communication_bus5_vrms1_vinst_va1__out * 0.0909);
    if((_communication_bus5_vrms1_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus5_vrms1_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus5_vrms1_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus5_vrms1_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus5_vrms1_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus5_vrms1_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus5_vrms1_rms_calc_fast__var_eff_s = _communication_bus5_vrms1_rms_calc_fast__v_sq_sum_state;
        _communication_bus5_vrms1_rms_calc_fast__period = (float)_communication_bus5_vrms1_rms_calc_fast__pc_cnt_1_state;
        _communication_bus5_vrms1_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus5.Vrms1.sys1
    // Generated from the component: Communication.Bus5.Vrms4.rms_calc_fast
    _communication_bus5_vrms4_rms_calc_fast__v_sq_sum_state = _communication_bus5_vrms4_rms_calc_fast__v_sq_sum_state + _communication_bus5_vrms4_vinst_va1__out * _communication_bus5_vrms4_vinst_va1__out;
    _communication_bus5_vrms4_rms_calc_fast__var_filt_old = _communication_bus5_vrms4_rms_calc_fast__var_filt;
    _communication_bus5_vrms4_rms_calc_fast__var_filt = (_communication_bus5_vrms4_rms_calc_fast__var_filt_old * 0.909 + _communication_bus5_vrms4_vinst_va1__out * 0.0909);
    if((_communication_bus5_vrms4_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus5_vrms4_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus5_vrms4_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus5_vrms4_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus5_vrms4_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus5_vrms4_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus5_vrms4_rms_calc_fast__var_eff_s = _communication_bus5_vrms4_rms_calc_fast__v_sq_sum_state;
        _communication_bus5_vrms4_rms_calc_fast__period = (float)_communication_bus5_vrms4_rms_calc_fast__pc_cnt_1_state;
        _communication_bus5_vrms4_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus5.Vrms4.sys1
    // Generated from the component: Communication.Bus5.Vrms5.rms_calc_fast
    _communication_bus5_vrms5_rms_calc_fast__v_sq_sum_state = _communication_bus5_vrms5_rms_calc_fast__v_sq_sum_state + _communication_bus5_vrms5_vinst_va1__out * _communication_bus5_vrms5_vinst_va1__out;
    _communication_bus5_vrms5_rms_calc_fast__var_filt_old = _communication_bus5_vrms5_rms_calc_fast__var_filt;
    _communication_bus5_vrms5_rms_calc_fast__var_filt = (_communication_bus5_vrms5_rms_calc_fast__var_filt_old * 0.909 + _communication_bus5_vrms5_vinst_va1__out * 0.0909);
    if((_communication_bus5_vrms5_rms_calc_fast__var_filt >= 0.0f) && (_communication_bus5_vrms5_rms_calc_fast__var_filt_old < 0.0f)) {
        _communication_bus5_vrms5_rms_calc_fast__var_zc = 1;
    }
    else {
        _communication_bus5_vrms5_rms_calc_fast__var_zc = 0;
    }
    //square sum and period update on signal zero cross
    if ((_communication_bus5_vrms5_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus5_vrms5_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus5_vrms5_rms_calc_fast__var_eff_s = _communication_bus5_vrms5_rms_calc_fast__v_sq_sum_state;
        _communication_bus5_vrms5_rms_calc_fast__period = (float)_communication_bus5_vrms5_rms_calc_fast__pc_cnt_1_state;
        _communication_bus5_vrms5_rms_calc_fast__v_sq_sum_state = 0.0f;
    }
    // Generated from the component: Communication.Bus5.Vrms5.sys1
    // Generated from the component: Communication.Bus2.Vrms1.rt1.Input
    _communication_bus2_vrms1_rt1_output__out = _communication_bus2_vrms1_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus2.Vrms1.rt2.Input
    _communication_bus2_vrms1_rt2_output__out = _communication_bus2_vrms1_rms_calc_fast__period;
    // Generated from the component: Communication.Bus2.Vrms1.t1
    // Generated from the component: Communication.Bus2.Vrms4.rt1.Input
    _communication_bus2_vrms4_rt1_output__out = _communication_bus2_vrms4_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus2.Vrms4.rt2.Input
    _communication_bus2_vrms4_rt2_output__out = _communication_bus2_vrms4_rms_calc_fast__period;
    // Generated from the component: Communication.Bus2.Vrms4.t1
    // Generated from the component: Communication.Bus2.Vrms5.rt1.Input
    _communication_bus2_vrms5_rt1_output__out = _communication_bus2_vrms5_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus2.Vrms5.rt2.Input
    _communication_bus2_vrms5_rt2_output__out = _communication_bus2_vrms5_rms_calc_fast__period;
    // Generated from the component: Communication.Bus2.Vrms5.t1
    // Generated from the component: Communication.Bus4.Vrms1.rt1.Input
    _communication_bus4_vrms1_rt1_output__out = _communication_bus4_vrms1_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus4.Vrms1.rt2.Input
    _communication_bus4_vrms1_rt2_output__out = _communication_bus4_vrms1_rms_calc_fast__period;
    // Generated from the component: Communication.Bus4.Vrms1.t1
    // Generated from the component: Communication.Bus4.Vrms4.rt1.Input
    _communication_bus4_vrms4_rt1_output__out = _communication_bus4_vrms4_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus4.Vrms4.rt2.Input
    _communication_bus4_vrms4_rt2_output__out = _communication_bus4_vrms4_rms_calc_fast__period;
    // Generated from the component: Communication.Bus4.Vrms4.t1
    // Generated from the component: Communication.Bus4.Vrms5.rt1.Input
    _communication_bus4_vrms5_rt1_output__out = _communication_bus4_vrms5_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus4.Vrms5.rt2.Input
    _communication_bus4_vrms5_rt2_output__out = _communication_bus4_vrms5_rms_calc_fast__period;
    // Generated from the component: Communication.Bus4.Vrms5.t1
    // Generated from the component: Communication.Bus5.Vrms1.rt1.Input
    _communication_bus5_vrms1_rt1_output__out = _communication_bus5_vrms1_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus5.Vrms1.rt2.Input
    _communication_bus5_vrms1_rt2_output__out = _communication_bus5_vrms1_rms_calc_fast__period;
    // Generated from the component: Communication.Bus5.Vrms1.t1
    // Generated from the component: Communication.Bus5.Vrms4.rt1.Input
    _communication_bus5_vrms4_rt1_output__out = _communication_bus5_vrms4_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus5.Vrms4.rt2.Input
    _communication_bus5_vrms4_rt2_output__out = _communication_bus5_vrms4_rms_calc_fast__period;
    // Generated from the component: Communication.Bus5.Vrms4.t1
    // Generated from the component: Communication.Bus5.Vrms5.rt1.Input
    _communication_bus5_vrms5_rt1_output__out = _communication_bus5_vrms5_rms_calc_fast__var_eff_s;
    // Generated from the component: Communication.Bus5.Vrms5.rt2.Input
    _communication_bus5_vrms5_rt2_output__out = _communication_bus5_vrms5_rms_calc_fast__period;
    // Generated from the component: Communication.Bus5.Vrms5.t1
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Communication.Bus2.Vrms1.rms_calc_fast
    if ((_communication_bus2_vrms1_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus2_vrms1_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus2_vrms1_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus2_vrms1_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus2.Vrms4.rms_calc_fast
    if ((_communication_bus2_vrms4_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus2_vrms4_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus2_vrms4_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus2_vrms4_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus2.Vrms5.rms_calc_fast
    if ((_communication_bus2_vrms5_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus2_vrms5_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus2_vrms5_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus2_vrms5_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus4.Vrms1.rms_calc_fast
    if ((_communication_bus4_vrms1_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus4_vrms1_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus4_vrms1_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus4_vrms1_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus4.Vrms4.rms_calc_fast
    if ((_communication_bus4_vrms4_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus4_vrms4_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus4_vrms4_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus4_vrms4_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus4.Vrms5.rms_calc_fast
    if ((_communication_bus4_vrms5_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus4_vrms5_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus4_vrms5_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus4_vrms5_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus5.Vrms1.rms_calc_fast
    if ((_communication_bus5_vrms1_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus5_vrms1_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus5_vrms1_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus5_vrms1_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus5.Vrms4.rms_calc_fast
    if ((_communication_bus5_vrms4_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus5_vrms4_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus5_vrms4_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus5_vrms4_rms_calc_fast__pc_cnt_1_state ++;
    // Generated from the component: Communication.Bus5.Vrms5.rms_calc_fast
    if ((_communication_bus5_vrms5_rms_calc_fast__var_zc == 1) || (5000 == _communication_bus5_vrms5_rms_calc_fast__pc_cnt_1_state)) {
        _communication_bus5_vrms5_rms_calc_fast__pc_cnt_1_state = 0;
    }
    _communication_bus5_vrms5_rms_calc_fast__pc_cnt_1_state ++;
    //@cmp.update.block.end
}
void TimerCounterHandler_1_sys_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_1");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Communication.Bus2.Vrms1.rms_calc_slow
    if(_communication_bus2_vrms1_rt2_output__out > 0.0f) {
        _communication_bus2_vrms1_rms_calc_slow__var_rms = sqrtf(_communication_bus2_vrms1_rt1_output__out / _communication_bus2_vrms1_rt2_output__out);
    }
    else {
        _communication_bus2_vrms1_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus2.Vrms4.rms_calc_slow
    if(_communication_bus2_vrms4_rt2_output__out > 0.0f) {
        _communication_bus2_vrms4_rms_calc_slow__var_rms = sqrtf(_communication_bus2_vrms4_rt1_output__out / _communication_bus2_vrms4_rt2_output__out);
    }
    else {
        _communication_bus2_vrms4_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus2.Vrms5.rms_calc_slow
    if(_communication_bus2_vrms5_rt2_output__out > 0.0f) {
        _communication_bus2_vrms5_rms_calc_slow__var_rms = sqrtf(_communication_bus2_vrms5_rt1_output__out / _communication_bus2_vrms5_rt2_output__out);
    }
    else {
        _communication_bus2_vrms5_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus4.Vrms1.rms_calc_slow
    if(_communication_bus4_vrms1_rt2_output__out > 0.0f) {
        _communication_bus4_vrms1_rms_calc_slow__var_rms = sqrtf(_communication_bus4_vrms1_rt1_output__out / _communication_bus4_vrms1_rt2_output__out);
    }
    else {
        _communication_bus4_vrms1_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus4.Vrms4.rms_calc_slow
    if(_communication_bus4_vrms4_rt2_output__out > 0.0f) {
        _communication_bus4_vrms4_rms_calc_slow__var_rms = sqrtf(_communication_bus4_vrms4_rt1_output__out / _communication_bus4_vrms4_rt2_output__out);
    }
    else {
        _communication_bus4_vrms4_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus4.Vrms5.rms_calc_slow
    if(_communication_bus4_vrms5_rt2_output__out > 0.0f) {
        _communication_bus4_vrms5_rms_calc_slow__var_rms = sqrtf(_communication_bus4_vrms5_rt1_output__out / _communication_bus4_vrms5_rt2_output__out);
    }
    else {
        _communication_bus4_vrms5_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus5.Vrms1.rms_calc_slow
    if(_communication_bus5_vrms1_rt2_output__out > 0.0f) {
        _communication_bus5_vrms1_rms_calc_slow__var_rms = sqrtf(_communication_bus5_vrms1_rt1_output__out / _communication_bus5_vrms1_rt2_output__out);
    }
    else {
        _communication_bus5_vrms1_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus5.Vrms4.rms_calc_slow
    if(_communication_bus5_vrms4_rt2_output__out > 0.0f) {
        _communication_bus5_vrms4_rms_calc_slow__var_rms = sqrtf(_communication_bus5_vrms4_rt1_output__out / _communication_bus5_vrms4_rt2_output__out);
    }
    else {
        _communication_bus5_vrms4_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus5.Vrms5.rms_calc_slow
    if(_communication_bus5_vrms5_rt2_output__out > 0.0f) {
        _communication_bus5_vrms5_rms_calc_slow__var_rms = sqrtf(_communication_bus5_vrms5_rt1_output__out / _communication_bus5_vrms5_rt2_output__out);
    }
    else {
        _communication_bus5_vrms5_rms_calc_slow__var_rms = 0.0f;
    }
    // Generated from the component: Communication.Bus2.Vrms1.rms
    HIL_OutAO(0x2000, _communication_bus2_vrms1_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus2.Vrms1.sys2
    // Generated from the component: Communication.Bus2.Vrms4.rms
    HIL_OutAO(0x2001, _communication_bus2_vrms4_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus2.Vrms4.sys2
    // Generated from the component: Communication.Bus2.Vrms5.rms
    HIL_OutAO(0x2002, _communication_bus2_vrms5_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus2.Vrms5.sys2
    // Generated from the component: Communication.Bus4.Vrms1.rms
    HIL_OutAO(0x2003, _communication_bus4_vrms1_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus4.Vrms1.sys2
    // Generated from the component: Communication.Bus4.Vrms4.rms
    HIL_OutAO(0x2004, _communication_bus4_vrms4_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus4.Vrms4.sys2
    // Generated from the component: Communication.Bus4.Vrms5.rms
    HIL_OutAO(0x2005, _communication_bus4_vrms5_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus4.Vrms5.sys2
    // Generated from the component: Communication.Bus5.Vrms1.rms
    HIL_OutAO(0x2006, _communication_bus5_vrms1_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus5.Vrms1.sys2
    // Generated from the component: Communication.Bus5.Vrms4.rms
    HIL_OutAO(0x2007, _communication_bus5_vrms4_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus5.Vrms4.sys2
    // Generated from the component: Communication.Bus5.Vrms5.rms
    HIL_OutAO(0x2008, _communication_bus5_vrms5_rms_calc_slow__var_rms);
    // Generated from the component: Communication.Bus5.Vrms5.sys2
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------