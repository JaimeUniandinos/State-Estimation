# NOTE: Variables and functions defined here will be
# available for use in all Macro and Expression scripts.
# NOTE: This code is always executed prior simulation start.

# Variable 'SETTINGS_DIR' holds directory where loaded Panel .cus file is located.
# Also you can call 'get_settings_dir_path()' function in any
# Macro and Expression scripts to get the same directory.
SETTINGS_DIR = get_settings_dir_path()

# The 'add_to_python_path(folder)' function can be used to add custom folder
# with Python files and packages to the PYTHONPATH. After folder is added, all Python 
# files and Python packages from it can be imported into the SCADA Namespace.

# HIL API is imported as 'hil'
# SCADA API is imported as 'panel'
# SCADA API constants are imported as 'api_const'
# Numpy module is imported as 'np'
# Scipy module is imported as 'sp'
# Schematic Editor model namespace is imported as 'scm'
# Function for printing to HIL SCADA Message log is imported as 'printf'.


# numero de buses 
#         |  From |  To   |   R     |   X     |     B/2  |  X'mer  |
#         |  Bus  | Bus   |  pu     |  pu     |     pu   | TAP (a) |
import math
linedata9 =[[1, 4, complex(0.00, 0.0576),    complex(0, 0.00), 1],
            [4, 5, complex(0.017, 0.092),   complex(0, 0.079), 1],
            [5, 6, complex(0.039, 0.170),   complex(0, 0.179), 1],
            [3, 6, complex(0.0, 0.0586), complex(0, 0.0), 1],
            [6, 7, complex(0.0119, 0.1008),  complex(0, 0.1045), 1],
            [7, 8, complex(0.0085, 0.072),   complex(0, 0.0745), 1],
            [8, 2, complex(0.0, 0.0625),   complex(0, 0.0), 1],
            [8, 9, complex(0.032, 0.161),  complex(0, 0.153), 1],
            [9, 4, complex(0.01, 0.085),   complex(0, 0.088), 1]]
            
            
VN=[ complex(1.040*math.cos(math.radians(0)),1.040*math.sin(math.radians(0))),
        complex(1.025*math.cos(math.radians(9.280)),1.025*math.sin(math.radians(9.280))),#
        complex(1.025*math.cos(math.radians(4.665)),1.025*math.sin(math.radians(4.665))),
        complex(1.026*math.cos(math.radians(-2.217)),1.026*math.sin(math.radians(-2.217))),#
        complex(1.013*math.cos(math.radians(-3.687)),0.985*math.sin(math.radians(-3.687))),#
        complex(1.032*math.cos(math.radians(1.967)),1.032*math.sin(math.radians(1.967))),
        complex(1.016*math.cos(math.radians(0.728)),1.016*math.sin(math.radians(0.728))),
        complex(1.026*math.cos(math.radians(3.720)),1.026*math.sin(math.radians(3.720))),
        complex(0.996*math.cos(math.radians(-3.989)),0.996*math.sin(math.radians(-3.989)))]

VNP=[[1.026,-2.217],#
     [1.032,1.967],#
     [1.026,3.720]]
pin1=0
pin2=0
pin3=0
