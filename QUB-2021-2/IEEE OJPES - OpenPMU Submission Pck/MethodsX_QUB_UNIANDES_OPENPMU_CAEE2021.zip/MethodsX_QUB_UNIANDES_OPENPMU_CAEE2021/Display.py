# HIL API is imported as 'hil'
# NOTE: Only read functions are available from the HIL API

# HIL API is imported as 'hil'
# NOTE: Only read functions are available from the HIL API

# specify Text Display options ('text' part is mandatory)
global busV
global VNP
import cmath

textDisplayData = {

    # label text
     "text": " {:.3f} V at {:.3f}°".format(VNP[1][0], VNP[1][1])
,

    # text color: 'red', 'green', 'blue', 'orange', 'black'
    "text_color": 'black',
}

# mandatory variable used for storing value that will be displayed
displayValue = textDisplayData
